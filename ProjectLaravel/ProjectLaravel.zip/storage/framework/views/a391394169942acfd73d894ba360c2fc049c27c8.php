<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <title>Peminjaman</title>
</head>

<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Politeknik Negeri Bengkalis | D-IV Rakayasa Perangkat Lunak</a>
        </div>
    </nav>
    <div class="container">
        <div class="row mt-3">
            <div class="col">
                <h4 class="text-secondary">Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
            </div>
            <div class="col"></div>
            <div class="col-1"><a href="<?php echo e(route('logout')); ?>" style="text-decoration: none">
                    <p class="text-end text-black fw-semibold">Logout</p>
                </a></div>
        </div>
        <div class="row mt-3">
            <nav class="navbar navbar-expand-lg">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <h5>
                                <a class="nav-link"" aria-current="page" href="<?php echo e(route('admin.home')); ?>">Home</a>
                            </h5>
                        </li>
                        <li class="nav-item" style="margin-left: 30px">
                            <h5>
                                <a class="nav-link" aria-current="page" href="<?php echo e(route('admin.buku')); ?>">Buku</a>
                            </h5>
                        </li>
                        <li class="nav-item" style="margin-left: 30px">
                            <h5>
                                <a class="nav-link active" aria-current="page"
                                    href="<?php echo e(route('admin.peminjaman')); ?>">Peminjaman</a>
                            </h5>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>

        <div class="container mt-3">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Berhasil!</strong> <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(Session::get('failed')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Gagal!</strong> <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        </div>


        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-center">
                    <?php echo $chart->container(); ?>

                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col"></div>
            <div class="col-6">
                <form action="<?php echo e(route('admin.peminjaman')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="search" name="search" class="form-control rounded" placeholder="Cari id peminjam"
                            aria-label="Search" aria-describedby="search-addon" />
                        <button type="submit" class="btn btn-outline-primary">search</button>
                    </div>
                </form>
            </div>
            <div class="col"></div>
        </div>
        <div class="row mt-5">
            <div class="col"><a class="btn btn-info text-white" target="_blank"
                    href="<?php echo e(route('admin.cetakDataPeminjaman')); ?>"
                    style="text-decoration: none; margin-right: 30px">Cetak Data</a></div>
            <div class="col"></div>
            <div class="col-2">
                <a class="btn btn-success" href="<?php echo e(route('admin.tambahPeminjaman')); ?>"
                    style="text-decoration: none; margin-left: 30px">Tambah Data
                    +</a>
            </div>
        </div>
        <table class="table" style="margin-top: 10px">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nomor Anggota</th>
                    <th scope="col">Kode Buku</th>
                    <th scope="col">Tanggal Peminjaman</th>
                    <th scope="col">Tanggal Pengembalian</th>
                    <th scope="col">Status Peminjaman</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peminjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($index + $data->firstItem()); ?></td>
                        <td><?php echo e($peminjam->id_user); ?></td>
                        <td><?php echo e($peminjam->id_buku); ?></td>
                        <td><?php echo e($peminjam->tanggal_pinjam); ?></td>
                        <td><?php echo e($peminjam->tanggal_kembali); ?></td>
                        <td>
                            <span
                                class="<?php echo e($peminjam->status === 'Sudah Dikembalikan' ? 'fw-semibold text-success' : 'fw-semibold text-danger'); ?>">
                                <?php echo e($peminjam->status); ?>

                            </span>
                        </td>
                        <td>
                            <a class="btn btn-outline-primary"
                                href="/admin/detailPeminjaman/<?php echo e($peminjam->id); ?>/<?php echo e($peminjam->id_user); ?>/<?php echo e($peminjam->id_buku); ?>">Detail</a>
                            <a class="btn btn-outline-warning"
                                href="/admin/editPeminjaman/<?php echo e($peminjam->id); ?>">Edit</a>
                            <a class="btn btn-outline-danger"
                                href="/admin/deletePeminjaman/<?php echo e($peminjam->id); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><br>
        <?php echo e($data->links()); ?>

    </div><br><br><br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e($chart->cdn()); ?>"></script>
    <?php echo e($chart->script()); ?>

</body>

</html>
<?php /**PATH C:\xampp_php1\htdocs\ProjectLaravel\resources\views/admin/peminjaman.blade.php ENDPATH**/ ?>